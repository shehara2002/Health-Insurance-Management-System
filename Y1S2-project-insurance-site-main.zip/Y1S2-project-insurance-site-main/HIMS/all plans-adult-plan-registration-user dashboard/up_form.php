<script>
        

        // Function to display the claim request form
        function showForm() {
            document.getElementById("registrationForm").style.display = "block";
        }
    </script>
