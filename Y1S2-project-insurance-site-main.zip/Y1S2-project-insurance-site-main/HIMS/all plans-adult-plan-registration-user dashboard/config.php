<?php
  
    $con = new mysqli('localhost','root','','healthinsurance');

    if($con->connect_error)
    {
        die("Connection failed".$con->connect_error);
    }
    

?>